# otx-url

go install github.com/tomnomnom/otx-url@latest

cp -r /root/go/bin/otx-url /usr/local/bin

otx-url -l sub.txt -t 5 -o url.txt

otx-url -u tesla.com -t 5 -o url.txt 
