# Security Policy

## Reporting a Vulnerability

DO NOT CREATE AN ISSUE to report a security problem. Instead, please send an email to towfikislam24@gmail.com and we will acknowledge it within 3 working days.
