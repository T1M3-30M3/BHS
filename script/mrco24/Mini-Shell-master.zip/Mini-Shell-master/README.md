## Mini Shell
A Simple PHP Based Mini Web-Shell having common features like directory browser, command executor, uploader etc. 

### Note:
***This Script is intended to be used for educational purposes only, no-one involved in the creation of this script may be held responsible for any illegal acts brought by anyone by using this script***
